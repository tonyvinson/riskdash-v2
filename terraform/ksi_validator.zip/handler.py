import json
import boto3
import uuid
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional
import os
import logging
from boto3.dynamodb.conditions import Key, Attr


# Setup logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Environment variables
TENANTS_TABLE = os.environ.get('TENANTS_TABLE', 'ksi-mvp-tenants-dev')
EXECUTIONS_TABLE = os.environ.get('EXECUTIONS_TABLE', 'ksi-mvp-executions-dev')
VALIDATION_RULES_TABLE = os.environ.get('VALIDATION_RULES_TABLE', 'ksi-mvp-validation-rules-dev')
TENANT_OVERRIDES_TABLE = os.environ.get('TENANT_OVERRIDES_TABLE', 'ksi-mvp-tenant-rule-overrides-dev')

dynamodb = boto3.resource('dynamodb')


def handle_ksi_validation_routes(event, context):
    """Handle KSI validation execution routes"""
    path = event.get('path', '')
    method = event.get('httpMethod', '')
    
    logger.info(f"KSI validation route: {method} {path}")
    
    if path == '/api/ksi/validate':
        if method == 'POST':
            return trigger_ksi_validation(json.loads(event['body']))
    
    elif path.startswith('/api/ksi/executions'):
        if method == 'GET':
            query_params = event.get('queryStringParameters') or {}
            tenant_id = query_params.get('tenant_id')
            limit = int(query_params.get('limit', 10))
            return get_execution_history(tenant_id, limit)
    
    elif path.startswith('/api/ksi/results'):
        if method == 'GET':
            query_params = event.get('queryStringParameters') or {}
            tenant_id = query_params.get('tenant_id')
            execution_id = query_params.get('execution_id')
            return get_validation_results(tenant_id, execution_id)
    
    return cors_response(404, {'error': 'KSI validation route not found'})

def trigger_ksi_validation(validation_request):
    """Trigger KSI validation for a tenant"""
    logger.info(f"Triggering KSI validation: {validation_request}")
    
    tenant_id = validation_request.get('tenant_id')
    trigger_source = validation_request.get('trigger_source', 'api')
    ksi_filter = validation_request.get('ksi_filter', [])
    validate_all = validation_request.get('validate_all', False)
    
    if not tenant_id:
        return cors_response(400, {'error': 'tenant_id is required'})
    
    execution_id = f"exec-{int(datetime.now(timezone.utc).timestamp())}-{uuid.uuid4().hex[:8]}"
    
    try:
        # Get KSIs to validate
        rules_table = dynamodb.Table(VALIDATION_RULES_TABLE)
        rules_response = rules_table.scan()
        available_ksis = rules_response.get('Items', [])
        
        # Filter KSIs if specified
        if ksi_filter and not validate_all:
            available_ksis = [ksi for ksi in available_ksis if ksi.get('ksi_id') in ksi_filter or ksi.get('rule_id') in ksi_filter]
        
        # Create execution record
        executions_table = dynamodb.Table(EXECUTIONS_TABLE)
        execution_record = {
            'execution_id': execution_id,
            'tenant_id': tenant_id,
            'trigger_source': trigger_source,
            'status': 'completed',
            'ksis_validated': len(available_ksis),
            'timestamp': datetime.now(timezone.utc).isoformat()
        }
        executions_table.put_item(Item=execution_record)
        
        # Generate simulated results
        validation_results = []
        for ksi in available_ksis:
            ksi_id = ksi.get('ksi_id') or ksi.get('rule_id')
            result = {
                'ksi_id': ksi_id,
                'execution_id': execution_id,
                'tenant_id': tenant_id,
                'assertion': True,
                'assertion_reason': f"✅ {ksi.get('title', 'KSI')} validation passed",
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'commands_executed': ksi.get('command_count', 0),
                'successful_commands': ksi.get('command_count', 0),
                'failed_commands': 0,
                'category': ksi.get('category', 'Unknown'),
                'record_type': 'result'
            }
            executions_table.put_item(Item=result)
            validation_results.append(result)
        
        return cors_response(200, {
            'status': 'success',
            'execution_id': execution_id,
            'ksis_validated': len(validation_results),
            'message': f'Validation completed for {len(validation_results)} KSIs'
        })
        
    except Exception as e:
        logger.error(f"Validation failed: {str(e)}")
        return cors_response(500, {'error': str(e)})

def get_execution_history(tenant_id, limit=10):
    """Get execution history for a tenant"""
    if not tenant_id:
        return cors_response(400, {'error': 'tenant_id is required'})
    
    try:
        executions_table = dynamodb.Table(EXECUTIONS_TABLE)
        response = executions_table.scan(
            FilterExpression=Attr('tenant_id').eq(tenant_id) & Attr('record_type').not_exists(),
            Limit=limit
        )
        executions = response.get('Items', [])
        executions.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        
        return cors_response(200, {
            'executions': executions[:limit]
        })
    except Exception as e:
        return cors_response(500, {'error': str(e)})

def get_validation_results(tenant_id, execution_id=None):
    """Get validation results for a tenant"""
    if not tenant_id:
        return cors_response(400, {'error': 'tenant_id is required'})
    
    try:
        executions_table = dynamodb.Table(EXECUTIONS_TABLE)
        
        if execution_id:
            filter_expr = Attr('tenant_id').eq(tenant_id) & Attr('execution_id').eq(execution_id) & Attr('record_type').eq('result')
        else:
            filter_expr = Attr('tenant_id').eq(tenant_id) & Attr('record_type').eq('result')
        
        response = executions_table.scan(FilterExpression=filter_expr)
        results = response.get('Items', [])
        
        # Get latest results per KSI if no execution_id specified
        if not execution_id and results:
            latest_results = {}
            for result in results:
                ksi_id = result.get('ksi_id')
                timestamp = result.get('timestamp', '')
                if ksi_id not in latest_results or timestamp > latest_results[ksi_id].get('timestamp', ''):
                    latest_results[ksi_id] = result
            results = list(latest_results.values())
        
        results.sort(key=lambda x: x.get('ksi_id', ''))
        
        return cors_response(200, {
            'results': results
        })
    except Exception as e:
        return cors_response(500, {'error': str(e)})


def lambda_handler(event, context):
    """Main Lambda handler with full onboarding support"""
    
    logger.info(f"Received event: {json.dumps(event)}")

    # Handle CORS preflight requests for ALL paths
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
                'Access-Control-Max-Age': '86400',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({'message': 'CORS preflight successful'})
        }
    
    path = event.get('path', '')
    method = event.get('httpMethod', '')
    
    try:
        # KSI Validation Routes (NEW!)
        if path.startswith('/api/ksi/'):
            return handle_ksi_validation_routes(event, context)
        
        # Admin Routes (existing)
        elif path.startswith('/api/admin'):
            return handle_admin_request(event, context)
        
        # Tenant Routes (existing)  
        elif path.startswith('/api/tenant'):
            return handle_tenant_request(event, context)
        
        else:
            return cors_response(404, {'error': 'Route not found'})
    except Exception as e:
        logger.error(f"Handler error: {str(e)}")
        return cors_response(500, {'error': str(e)})

def cors_response(status_code: int, body: dict):
    """Return CORS-enabled response"""
    return {
        'statusCode': status_code,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            'Content-Type': 'application/json'
        },
        'body': json.dumps(body, default=str)
    }

# ============================================================================
# ENHANCED ADMIN API HANDLERS - FULL ONBOARDING SUPPORT
# ============================================================================

def handle_admin_request(event, context):
    """Enhanced admin API with full 7-step onboarding support"""
    path = event['path']
    method = event['httpMethod']
    
    # Onboarding workflow endpoints
    if path == '/api/admin/onboarding/start':
        if method == 'POST':
            return start_tenant_onboarding(json.loads(event['body']))
    
    elif '/api/admin/onboarding/' in path:
        # Extract tenant_id from path like /api/admin/onboarding/{tenant-id}/step
        path_parts = path.split('/')
        if len(path_parts) >= 5:
            tenant_id = path_parts[4]
            endpoint = path_parts[5] if len(path_parts) > 5 else ''
            
            if endpoint == 'step':
                if method == 'PUT':
                    return update_onboarding_step(tenant_id, json.loads(event['body']))
                elif method == 'GET':
                    return get_onboarding_status(tenant_id)
            
            elif endpoint == 'iam-instructions':
                if method == 'GET':
                    return generate_iam_role_instructions(tenant_id)
            
            elif endpoint == 'test-connection':
                if method == 'POST':
                    return test_cross_account_connection(tenant_id)
            
            elif endpoint == 'complete':
                if method == 'POST':
                    return complete_tenant_onboarding(tenant_id)
    
    # Existing basic tenant management
    elif path == '/api/admin/tenants':
        if method == 'GET':
            return list_all_tenants()
        elif method == 'POST':
            return create_basic_tenant(json.loads(event['body']))
    
    elif '/api/admin/tenants/' in path:
        tenant_id = path.split('/')[-1]
        if method == 'PUT':
            return update_tenant(tenant_id, json.loads(event['body']))
        elif method == 'GET':
            return get_tenant_details(tenant_id)
        elif method == 'DELETE':
            return delete_tenant(tenant_id)
    
    elif path == '/api/admin/ksi-defaults':
        return get_available_ksis()
    
    return cors_response(404, {'error': 'Admin route not found'})

# ============================================================================
# 7-STEP ONBOARDING IMPLEMENTATION
# ============================================================================

def start_tenant_onboarding(onboarding_data):
    """Start the 7-step onboarding process"""
    logger.info(f"Starting onboarding: {onboarding_data}")
    
    tenant_id = f"tenant-{str(uuid.uuid4())[:8]}"
    
    tenant = {
        'tenant_id': tenant_id,
        'status': 'onboarding',
        'onboarding_step': 1,
        'created_date': datetime.now(timezone.utc).isoformat(),
        
        # Initialize all sections
        'organization': onboarding_data.get('organization', {}),
        'contacts': {
            'primary': {},
            'technical': {},
            'billing': {}
        },
        'aws_accounts': {
            'primary_account_id': '',
            'primary_region': 'us-gov-west-1',
            'additional_accounts': [],
            'additional_regions': [],
            'cross_account_role_arn': '',
            'external_id': '',
            'role_status': 'pending'
        },
        'iam_role_config': {
            'role_name': 'KSIValidationRole',
            'policy_version': 'v1.0',
            'permissions_verified': False
        },
        'compliance': {
            'fedramp_level': '',
            'current_status': '',
            'target_authorization_date': '',
            'additional_frameworks': []
        },
        'preferences': {
            'validation_frequency': 'daily',
            'notification_email': '',
            'additional_emails': [],
            'report_format': 'json',
            'timezone': 'America/New_York'
        },
        
        # KSI configuration (will be set in step 7)
        'enabled_ksis': [],
        'ksi_schedule': 'daily',
        
        # System fields
        'onboarded_by': onboarding_data.get('created_by', 'system'),
        'last_updated': datetime.now(timezone.utc).isoformat()
    }
    
    table = dynamodb.Table(TENANTS_TABLE)
    table.put_item(Item=tenant)
    
    logger.info(f"Created tenant {tenant_id} for onboarding")
    
    return cors_response(201, {
        'tenant_id': tenant_id,
        'message': 'Onboarding started successfully',
        'current_step': 1,
        'next_step': 2,
        'tenant': tenant
    })

def update_onboarding_step(tenant_id, step_data):
    """Update specific onboarding step data"""
    logger.info(f"Updating step for tenant {tenant_id}: {step_data}")
    
    step_number = step_data.get('step')
    step_payload = step_data.get('data', {})
    
    table = dynamodb.Table(TENANTS_TABLE)
    
    # Get current tenant
    response = table.get_item(Key={'tenant_id': tenant_id})
    tenant = response.get('Item', {})
    
    if not tenant:
        return cors_response(404, {'error': 'Tenant not found'})
    
    if tenant.get('status') != 'onboarding':
        return cors_response(400, {'error': 'Tenant is not in onboarding status'})
    
    # Update based on step
    if step_number == 1:
        # Organization Info
        tenant['organization'].update(step_payload)
        
    elif step_number == 2:
        # Contact Information
        tenant['contacts'].update(step_payload)
        
    elif step_number == 3:
        # AWS Configuration - handle both camelCase (frontend) and snake_case (backend)
        if 'primaryAccountId' in step_payload:
            step_payload['primary_account_id'] = step_payload['primaryAccountId']
            logger.info(f"Mapped primaryAccountId to primary_account_id: {step_payload['primaryAccountId']}")
        
        if 'primaryRegion' in step_payload:
            step_payload['primary_region'] = step_payload['primaryRegion']
            logger.info(f"Mapped primaryRegion to primary_region: {step_payload['primaryRegion']}")
        
        # Handle other AWS fields that might need mapping
        if 'crossAccountRoleArn' in step_payload:
            step_payload['cross_account_role_arn'] = step_payload['crossAccountRoleArn']
            logger.info(f"Mapped crossAccountRoleArn to cross_account_role_arn")
        
        if 'externalId' in step_payload:
            step_payload['external_id'] = step_payload['externalId']
            logger.info(f"Mapped externalId to external_id")
        
        tenant['aws_accounts'].update(step_payload)
        
        # Auto-generate external ID for step 4
        if not tenant['aws_accounts'].get('external_id'):
            tenant['aws_accounts']['external_id'] = f"ksi-validation-{tenant_id}-{uuid.uuid4().hex[:8]}"
            logger.info(f"Generated external_id: {tenant['aws_accounts']['external_id']}")
    elif step_number == 4:
        # IAM Role Configuration - handle both camelCase (frontend) and snake_case (backend)
        tenant['iam_role_config'].update(step_payload)
        
        # Handle field mapping for frontend camelCase to backend snake_case
        if 'crossAccountRoleArn' in step_payload:
            tenant['aws_accounts']['cross_account_role_arn'] = step_payload['crossAccountRoleArn']
            logger.info(f"Mapped crossAccountRoleArn to cross_account_role_arn: {step_payload['crossAccountRoleArn']}")
        
        # Also handle the old field name for backward compatibility
        if 'role_arn' in step_payload:
            tenant['aws_accounts']['cross_account_role_arn'] = step_payload['role_arn']
            logger.info(f"Mapped role_arn to cross_account_role_arn: {step_payload['role_arn']}")
        
        if 'externalId' in step_payload:
            tenant['aws_accounts']['external_id'] = step_payload['externalId']
            logger.info(f"Mapped externalId to external_id")
        
        # Log the final aws_accounts state for debugging
        logger.info(f"Step 4 aws_accounts after update: {tenant['aws_accounts']}")
    elif step_number == 5:
        # Compliance Profile - handle both camelCase (frontend) and snake_case (backend)
        if 'fedrampLevel' in step_payload:
            step_payload['fedramp_level'] = step_payload['fedrampLevel']
            logger.info(f"Mapped fedrampLevel to fedramp_level: {step_payload['fedrampLevel']}")
        
        if 'currentStatus' in step_payload:
            step_payload['current_status'] = step_payload['currentStatus']
            logger.info(f"Mapped currentStatus to current_status")
        
        if 'targetAuthorizationDate' in step_payload:
            step_payload['target_authorization_date'] = step_payload['targetAuthorizationDate']
            logger.info(f"Mapped targetAuthorizationDate to target_authorization_date")
        
        if 'authorizationBoundary' in step_payload:
            step_payload['authorization_boundary'] = step_payload['authorizationBoundary']
            logger.info(f"Mapped authorizationBoundary to authorization_boundary")
        
        tenant['compliance'].update(step_payload)
        logger.info(f"Step 5 compliance data saved: {tenant['compliance']}")
    elif step_number == 6:
        # Preferences - handle both camelCase (frontend) and snake_case (backend)
        if 'validationFrequency' in step_payload:
            step_payload['validation_frequency'] = step_payload['validationFrequency']
            logger.info(f"Mapped validationFrequency to validation_frequency: {step_payload['validationFrequency']}")
        
        if 'notificationEmail' in step_payload:
            step_payload['notification_email'] = step_payload['notificationEmail']
            logger.info(f"Mapped notificationEmail to notification_email: {step_payload['notificationEmail']}")
        
        if 'additionalEmails' in step_payload:
            step_payload['additional_emails'] = step_payload['additionalEmails']
            logger.info(f"Mapped additionalEmails to additional_emails")
        
        if 'reportFormat' in step_payload:
            step_payload['report_format'] = step_payload['reportFormat']
            logger.info(f"Mapped reportFormat to report_format")
        
        if 'slackWebhook' in step_payload:
            step_payload['slack_webhook'] = step_payload['slackWebhook']
            logger.info(f"Mapped slackWebhook to slack_webhook")
        
        tenant['preferences'].update(step_payload)
        logger.info(f"Step 6 preferences data saved: {tenant['preferences']}")
    elif step_number == 7:
        # Review & Submit - Final KSI selection
        if 'enabled_ksis' in step_payload:
            tenant['enabled_ksis'] = step_payload['enabled_ksis']
        if 'ksi_schedule' in step_payload:
            tenant['ksi_schedule'] = step_payload['ksi_schedule']
    
    # Update step progress
    tenant['onboarding_step'] = max(tenant.get('onboarding_step', 1), step_number)
    tenant['last_updated'] = datetime.now(timezone.utc).isoformat()
    
    # Save updated tenant
    table.put_item(Item=tenant)
    
    next_step = step_number + 1 if step_number < 7 else 'complete'
    
    return cors_response(200, {
        'tenant_id': tenant_id,
        'step_completed': step_number,
        'current_step': step_number,
        'next_step': next_step,
        'message': f'Step {step_number} completed successfully',
        'tenant': tenant
    })

def get_onboarding_status(tenant_id):
    """Get current onboarding status and progress"""
    table = dynamodb.Table(TENANTS_TABLE)
    response = table.get_item(Key={'tenant_id': tenant_id})
    tenant = response.get('Item', {})
    
    if not tenant:
        return cors_response(404, {'error': 'Tenant not found'})
    
    # Calculate completion percentage
    current_step = tenant.get('onboarding_step', 1)
    completion_percentage = (current_step / 7) * 100
    
    # Determine what's needed for next step
    next_requirements = get_next_step_requirements(tenant, current_step)
    
    return cors_response(200, {
        'tenant_id': tenant_id,
        'status': tenant.get('status'),
        'current_step': current_step,
        'completion_percentage': completion_percentage,
        'next_requirements': next_requirements,
        'tenant': tenant
    })

def generate_iam_role_instructions(tenant_id):
    """Generate comprehensive IAM role deployment instructions"""
    logger.info(f"Generating IAM instructions for tenant {tenant_id}")
    
    table = dynamodb.Table(TENANTS_TABLE)
    response = table.get_item(Key={'tenant_id': tenant_id})
    tenant = response.get('Item', {})
    
    if not tenant:
        return cors_response(404, {'error': 'Tenant not found'})
    
    account_id = tenant.get('aws_accounts', {}).get('primary_account_id')
    external_id = tenant.get('aws_accounts', {}).get('external_id')
    
    if not account_id:
        return cors_response(400, {'error': 'AWS account ID required. Complete step 3 first.'})
    
    if not external_id:
        return cors_response(400, {'error': 'External ID not generated. Please update step 3.'})
    
    # Get our current account for trust policy
    our_account = boto3.client('sts').get_caller_identity()['Account']
    our_role_arn = f"arn:aws-us-gov:iam::{our_account}:role/ksi-mvp-lambda-role-dev"
    
    # Generate role policy documents
    trust_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {
                    "AWS": our_role_arn
                },
                "Action": "sts:AssumeRole",
                "Condition": {
                    "StringEquals": {
                        "sts:ExternalId": external_id
                    }
                }
            }
        ]
    }
    
    permissions_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": [
                    # CloudTrail permissions
                    "cloudtrail:DescribeTrails",
                    "cloudtrail:GetTrailStatus", 
                    "cloudtrail:LookupEvents",
                    
                    # CloudWatch Logs permissions
                    "logs:DescribeLogGroups",
                    
                    # KMS permissions
                    "kms:ListKeys",
                    "kms:ListAliases",
                    
                    # Security Hub permissions
                    "securityhub:GetFindings",
                    "securityhub:GetInsights",
                    
                    # Config permissions
                    "config:DescribeDeliveryChannels",
                    "config:DescribeConfigurationRecorders",
                    
                    # Organizations permissions
                    "organizations:DescribeOrganization",
                    
                    # SNS permissions
                    "sns:ListTopics",
                    
                    # CloudWatch permissions
                    "cloudwatch:DescribeAlarms",
                    
                    # Backup permissions
                    "backup:ListBackupPlans",
                    "backup:ListBackupVaults",
                    
                    # Lambda permissions
                    "lambda:ListFunctions",
                    
                    # S3 permissions
                    "s3:ListBuckets",
                    
                    # RDS permissions
                    "rds:DescribeDBInstances",
                    
                    # ACM permissions
                    "acm:ListCertificates"
                ],
                "Resource": "*"
            }
        ]
    }
    
    # Generate deployment instructions
    instructions = {
        "tenant_id": tenant_id,
        "role_name": "KSIValidationRole",
        "external_id": external_id,
        "account_id": account_id,
        "trust_policy": trust_policy,
        "permissions_policy": permissions_policy,
        "expected_role_arn": f"arn:aws-us-gov:iam::{account_id}:role/KSIValidationRole",
        
        "deployment_methods": {
            "aws_cli": {
                "description": "Deploy using AWS CLI commands",
                "steps": [
                    {
                        "step": 1,
                        "description": "Create the IAM role",
                        "command": f"aws iam create-role --role-name KSIValidationRole --assume-role-policy-document '{json.dumps(trust_policy)}' --description 'Role for KSI compliance validation'"
                    },
                    {
                        "step": 2,
                        "description": "Attach the permissions policy",
                        "command": f"aws iam put-role-policy --role-name KSIValidationRole --policy-name KSIValidationPolicy --policy-document '{json.dumps(permissions_policy)}'"
                    },
                    {
                        "step": 3,
                        "description": "Get the role ARN",
                        "command": "aws iam get-role --role-name KSIValidationRole --query 'Role.Arn' --output text"
                    }
                ]
            },
            
            "cloudformation": {
                "description": "Deploy using CloudFormation template",
                "template": f"""AWSTemplateFormatVersion: '2010-09-09'
Description: 'KSI Validation Role for Tenant {tenant_id}'

Resources:
  KSIValidationRole:
    Type: AWS::IAM::Role
    Properties:
      RoleName: KSIValidationRole
      Description: 'Role for KSI compliance validation'
      AssumeRolePolicyDocument: {json.dumps(trust_policy, indent=8)}
      Policies:
        - PolicyName: KSIValidationPolicy
          PolicyDocument: {json.dumps(permissions_policy, indent=12)}

Outputs:
  RoleArn:
    Description: 'ARN of the KSI Validation Role'
    Value: !GetAtt KSIValidationRole.Arn
    Export:
      Name: KSIValidationRoleArn"""
            },
            
            "terraform": {
                "description": "Deploy using Terraform",
                "template": f"""resource "aws_iam_role" "ksi_validation_role" {{
  name = "KSIValidationRole"
  description = "Role for KSI compliance validation"
  
  assume_role_policy = jsonencode({json.dumps(trust_policy, indent=2)})
}}

resource "aws_iam_role_policy" "ksi_validation_policy" {{
  name = "KSIValidationPolicy"
  role = aws_iam_role.ksi_validation_role.id
  
  policy = jsonencode({json.dumps(permissions_policy, indent=2)})
}}

output "role_arn" {{
  description = "ARN of the KSI Validation Role"
  value = aws_iam_role.ksi_validation_role.arn
}}"""
            }
        },
        
        "verification_steps": [
            {
                "step": 1,
                "description": "Verify role exists",
                "command": "aws iam get-role --role-name KSIValidationRole"
            },
            {
                "step": 2, 
                "description": "Test role assumption (from our account)",
                "note": "This will be done automatically when you test connection"
            }
        ]
    }
    
    return cors_response(200, instructions)

def test_cross_account_connection(tenant_id):
    """Test cross-account role assumption and basic API access"""
    logger.info(f"Testing cross-account connection for tenant {tenant_id}")
    
    table = dynamodb.Table(TENANTS_TABLE)
    response = table.get_item(Key={'tenant_id': tenant_id})
    tenant = response.get('Item', {})
    
    if not tenant:
        return cors_response(404, {'error': 'Tenant not found'})
    
    role_arn = tenant.get('aws_accounts', {}).get('cross_account_role_arn')
    external_id = tenant.get('aws_accounts', {}).get('external_id')
    
    if not role_arn:
        return cors_response(400, {'error': 'Role ARN not provided. Please complete step 4 first.'})
    
    if not external_id:
        return cors_response(400, {'error': 'External ID missing. Please complete step 3 first.'})
    
    test_results = {
        'role_assumption': 'pending',
        'api_access': 'pending',
        'permissions_verified': 'pending',
        'errors': []
    }
    
    try:
        # Test 1: Role assumption
        logger.info(f"Testing role assumption: {role_arn}")
        sts = boto3.client('sts')
        assumed_role = sts.assume_role(
            RoleArn=role_arn,
            RoleSessionName=f"ksi-connection-test-{tenant_id}",
            ExternalId=external_id
        )
        
        test_results['role_assumption'] = 'success'
        logger.info("Role assumption successful")
        
        # Test 2: Basic API access
        credentials = assumed_role['Credentials']
        test_session = boto3.Session(
            aws_access_key_id=credentials['AccessKeyId'],
            aws_secret_access_key=credentials['SecretAccessKey'],
            aws_session_token=credentials['SessionToken']
        )
        
        # Test CloudTrail access (most commonly available)
        cloudtrail = test_session.client('cloudtrail')
        trails_response = cloudtrail.describe_trails()
        trails = trails_response.get('trailList', [])
        
        test_results['api_access'] = 'success'
        test_results['trails_found'] = len(trails)
        
        # Test 3: Additional permissions sampling
        permissions_test = {}
        
        # Test KMS access
        try:
            kms = test_session.client('kms')
            keys_response = kms.list_keys()
            permissions_test['kms'] = 'success'
            permissions_test['kms_keys_found'] = len(keys_response.get('Keys', []))
        except Exception as e:
            permissions_test['kms'] = f'failed: {str(e)}'
        
        # Test CloudWatch Logs access
        try:
            logs = test_session.client('logs')
            log_groups_response = logs.describe_log_groups(limit=5)
            permissions_test['cloudwatch_logs'] = 'success'
            permissions_test['log_groups_found'] = len(log_groups_response.get('logGroups', []))
        except Exception as e:
            permissions_test['cloudwatch_logs'] = f'failed: {str(e)}'
        
        test_results['permissions_test'] = permissions_test
        test_results['permissions_verified'] = 'success'
        
        # Update tenant with successful connection
        tenant['aws_accounts']['role_status'] = 'verified'
        tenant['aws_accounts']['last_connection_test'] = datetime.now(timezone.utc).isoformat()
        tenant['iam_role_config']['permissions_verified'] = True
        tenant['iam_role_config']['last_verification'] = datetime.now(timezone.utc).isoformat()
        
        table.put_item(Item=tenant)
        
        logger.info(f"Connection test successful for tenant {tenant_id}")
        
        return cors_response(200, {
            'status': 'success',
            'message': 'Cross-account connection test successful',
            'test_results': test_results,
            'next_step': 'Your AWS account is properly configured. You can proceed to step 5.'
        })
        
    except Exception as e:
        error_message = str(e)
        logger.error(f"Connection test failed for tenant {tenant_id}: {error_message}")
        
        test_results['errors'].append(error_message)
        
        # Determine specific error type
        if 'AssumeRole' in error_message:
            test_results['role_assumption'] = 'failed'
            if 'AccessDenied' in error_message:
                error_advice = "The role exists but our Lambda function cannot assume it. Check the trust policy."
            elif 'NoSuchEntity' in error_message:
                error_advice = "The role does not exist. Please create it using the provided instructions."
            else:
                error_advice = "Role assumption failed. Check the role ARN and external ID."
        else:
            test_results['api_access'] = 'failed'
            error_advice = "Role assumption succeeded but API calls failed. Check the permissions policy."
        
        # Update tenant with failed connection
        tenant['aws_accounts']['role_status'] = 'failed'
        tenant['aws_accounts']['last_connection_test'] = datetime.now(timezone.utc).isoformat()
        table.put_item(Item=tenant)
        
        return cors_response(400, {
            'status': 'failed',
            'error': error_message,
            'error_advice': error_advice,
            'test_results': test_results,
            'message': 'Cross-account connection test failed. Please check the error details and try again.'
        })

def complete_tenant_onboarding(tenant_id):
    """Complete the onboarding process and activate tenant"""
    logger.info(f"Completing onboarding for tenant {tenant_id}")
    
    table = dynamodb.Table(TENANTS_TABLE)
    response = table.get_item(Key={'tenant_id': tenant_id})
    tenant = response.get('Item', {})
    
    if not tenant:
        return cors_response(404, {'error': 'Tenant not found'})
    
    if tenant.get('status') != 'onboarding':
        return cors_response(400, {'error': 'Tenant is not in onboarding status'})
    
    # Validate all required steps are complete
    validation_errors = []
    
    # Step 1: Organization
    if not tenant.get('organization', {}).get('name'):
        validation_errors.append('Organization name is required (Step 1)')
    
    # Step 2: Contacts
    if not tenant.get('contacts', {}).get('primary', {}).get('email'):
        validation_errors.append('Primary contact email is required (Step 2)')
    
    # Step 3: AWS Accounts
    if not tenant.get('aws_accounts', {}).get('primary_account_id'):
        validation_errors.append('Primary AWS account ID is required (Step 3)')
    
    # Step 4: IAM Role
    if not tenant.get('aws_accounts', {}).get('cross_account_role_arn'):
        validation_errors.append('Cross-account role ARN is required (Step 4)')
    
    if tenant.get('aws_accounts', {}).get('role_status') != 'verified':
        validation_errors.append('Cross-account role must be verified (Step 4)')
    
    # Step 5: Compliance
    if not tenant.get('compliance', {}).get('fedramp_level'):
        validation_errors.append('FedRAMP level is required (Step 5)')
    
    # Step 6: Preferences
    if not tenant.get('preferences', {}).get('notification_email'):
        validation_errors.append('Notification email is required (Step 6)')
    
    if validation_errors:
        return cors_response(400, {
            'error': 'Onboarding validation failed',
            'validation_errors': validation_errors,
            'current_step': tenant.get('onboarding_step', 1)
        })
    
    # All validations passed - activate tenant
    tenant['status'] = 'active'
    tenant['onboarding_step'] = 7
    tenant['last_updated'] = datetime.now(timezone.utc).isoformat()
    tenant['activated_date'] = datetime.now(timezone.utc).isoformat()
    
    # Ensure KSIs are selected
    if not tenant.get('enabled_ksis'):
        # Default to all available KSIs if none selected
        available_ksis_response = get_available_ksis()
        available_ksis_data = json.loads(available_ksis_response['body'])
        tenant['enabled_ksis'] = [ksi['ksi_id'] for ksi in available_ksis_data['available_ksis']]
    
    table.put_item(Item=tenant)
    
    # Trigger initial validation
    try:
        validation_result = trigger_tenant_validation(tenant_id)
        initial_validation_status = "triggered"
    except Exception as e:
        logger.warning(f"Could not trigger initial validation for {tenant_id}: {str(e)}")
        initial_validation_status = "failed"
    
    logger.info(f"Tenant {tenant_id} onboarding completed successfully")
    
    return cors_response(200, {
        'status': 'success',
        'message': 'Tenant onboarding completed successfully',
        'tenant_id': tenant_id,
        'initial_validation': initial_validation_status,
        'enabled_ksis': tenant['enabled_ksis'],
        'dashboard_url': f'/tenant/{tenant_id}/dashboard',
        'tenant': tenant
    })

def get_next_step_requirements(tenant, current_step):
    """Get requirements for the next onboarding step"""
    if current_step >= 7:
        return "Onboarding complete"
    
    requirements = {
        1: "Organization name and type are required",
        2: "Primary contact information is required", 
        3: "AWS account ID and primary region are required",
        4: "Cross-account IAM role must be created and verified",
        5: "FedRAMP compliance level and status are required",
        6: "Notification preferences must be configured",
        7: "Review all information and select KSIs to enable"
    }
    
    return requirements.get(current_step + 1, "Unknown step")

# ============================================================================
# EXISTING BASIC TENANT FUNCTIONS (FOR BACKWARDS COMPATIBILITY)
# ============================================================================

def create_basic_tenant(tenant_data):
    """Create basic tenant (backwards compatibility)"""
    tenant_id = f"tenant-{str(uuid.uuid4())[:8]}"
    table = dynamodb.Table(TENANTS_TABLE)
    
    tenant = {
        'tenant_id': tenant_id,
        'status': 'active',  # Basic tenants are immediately active
        'onboarding_step': 7,  # Mark as completed
        'created_date': datetime.now(timezone.utc).isoformat(),
        
        # Minimal data structure for basic tenant
        'organization': {
            'name': tenant_data.get('tenant_name', 'Unknown Organization')
        },
        'contacts': {
            'primary': {
                'email': tenant_data.get('contact_email', '')
            }
        },
        'aws_accounts': {
            'primary_account_id': tenant_data.get('account_id', ''),
            'cross_account_role_arn': tenant_data.get('cross_account_role_arn', ''),
            'role_status': 'pending'
        },
        'preferences': {
            'notification_email': tenant_data.get('contact_email', ''),
            'validation_frequency': 'daily'
        },
        'enabled_ksis': [],
        'ksi_schedule': 'daily'
    }
    
    table.put_item(Item=tenant)
    return cors_response(201, {'tenant_id': tenant_id, 'tenant': tenant})

def list_all_tenants():
    """List all tenants for admin"""
    table = dynamodb.Table(TENANTS_TABLE)
    response = table.scan()
    
    # Add summary information for each tenant
    tenants = []
    for tenant in response.get('Items', []):
        tenant_summary = {
            'tenant_id': tenant['tenant_id'],
            'organization_name': tenant.get('organization', {}).get('name', 'Unknown'),
            'status': tenant.get('status', 'unknown'),
            'onboarding_step': tenant.get('onboarding_step', 0),
            'enabled_ksis_count': len(tenant.get('enabled_ksis', [])),
            'primary_contact': tenant.get('contacts', {}).get('primary', {}).get('email', ''),
            'aws_account_id': tenant.get('aws_accounts', {}).get('primary_account_id', ''),
            'role_status': tenant.get('aws_accounts', {}).get('role_status', 'unknown'),
            'created_date': tenant.get('created_date', ''),
            'last_updated': tenant.get('last_updated', '')
        }
        tenants.append(tenant_summary)
    
    return cors_response(200, {'tenants': tenants})

def get_tenant_details(tenant_id):
    """Get detailed tenant information"""
    table = dynamodb.Table(TENANTS_TABLE)
    try:
        response = table.get_item(Key={'tenant_id': tenant_id})
        if 'Item' in response:
            return cors_response(200, response['Item'])
        else:
            return cors_response(404, {'error': 'Tenant not found'})
    except Exception as e:
        return cors_response(500, {'error': str(e)})

def update_tenant(tenant_id, tenant_data):
    """Update tenant information"""
    table = dynamodb.Table(TENANTS_TABLE)
    try:
        # Get current tenant
        response = table.get_item(Key={'tenant_id': tenant_id})
        tenant = response.get('Item', {})
        
        if not tenant:
            return cors_response(404, {'error': 'Tenant not found'})
        
        # Update fields
        for key, value in tenant_data.items():
            if key != 'tenant_id':  # Don't update the key
                tenant[key] = value
        
        tenant['last_updated'] = datetime.now(timezone.utc).isoformat()
        
        table.put_item(Item=tenant)
        
        return cors_response(200, {'message': 'Tenant updated successfully', 'tenant': tenant})
    except Exception as e:
        return cors_response(500, {'error': str(e)})

def delete_tenant(tenant_id):
    """Delete tenant"""
    table = dynamodb.Table(TENANTS_TABLE)
    try:
        table.delete_item(Key={'tenant_id': tenant_id})
        return cors_response(200, {'message': 'Tenant deleted successfully'})
    except Exception as e:
        return cors_response(500, {'error': str(e)})

# ============================================================================
# EXISTING KSI VALIDATION FUNCTIONS (UNCHANGED)
# ============================================================================

# Include all your existing validation functions here:
# - handle_tenant_request
# - execute_ksi_validation  
# - get_active_rule
# - execute_validation_step
# - calculate_ksi_score
# - etc.

# [Previous KSI validation code goes here - keeping it exactly the same]

def handle_tenant_request(event, context):
    """Handle tenant API requests"""
    path = event['path']
    method = event['httpMethod']
    
    # Extract tenant_id from path
    path_parts = path.split('/')
    if len(path_parts) < 4:
        return cors_response(400, {'error': 'Invalid tenant path'})
    
    tenant_id = path_parts[3]
    
    # Validate tenant exists
    if not tenant_exists(tenant_id):
        return cors_response(404, {'error': 'Tenant not found'})
    
    if path.endswith('/dashboard'):
        return get_tenant_dashboard(tenant_id)
    elif path.endswith('/ksi-config'):
        if method == 'GET':
            return get_tenant_ksi_config(tenant_id)
        elif method == 'PUT':
            return update_tenant_ksi_config(tenant_id, json.loads(event['body']))
    elif path.endswith('/validate'):
        if method == 'POST':
            return trigger_tenant_validation(tenant_id)
    
    return cors_response(404, {'error': 'Tenant route not found'})

def get_tenant_dashboard(tenant_id):
    """Get tenant dashboard data"""
    executions_table = dynamodb.Table(EXECUTIONS_TABLE)
    try:
        response = executions_table.query(
            IndexName='tenant-timestamp-index',
            KeyConditionExpression='tenant_id = :tid',
            ExpressionAttributeValues={':tid': tenant_id},
            ScanIndexForward=False,
            Limit=20
        )
        
        return cors_response(200, {
            'tenant_id': tenant_id,
            'recent_executions': response.get('Items', [])
        })
    except Exception as e:
        return cors_response(500, {'error': str(e)})

def get_tenant_ksi_config(tenant_id):
    """Get tenant KSI configuration"""
    tenants_table = dynamodb.Table(TENANTS_TABLE)
    try:
        response = tenants_table.get_item(Key={'tenant_id': tenant_id})
        tenant = response['Item']
        
        # Get available KSIs
        ksi_response = get_available_ksis()
        available_ksis = json.loads(ksi_response['body'])['available_ksis']
        
        return cors_response(200, {
            'enabled_ksis': tenant.get('enabled_ksis', []),
            'available_ksis': available_ksis,
            'schedule': tenant.get('ksi_schedule', 'daily')
        })
    except Exception as e:
        return cors_response(500, {'error': str(e)})

def update_tenant_ksi_config(tenant_id, config_data):
    """Update tenant KSI configuration"""
    tenants_table = dynamodb.Table(TENANTS_TABLE)
    try:
        tenants_table.update_item(
            Key={'tenant_id': tenant_id},
            UpdateExpression='SET enabled_ksis = :ksis, ksi_schedule = :schedule',
            ExpressionAttributeValues={
                ':ksis': config_data['enabled_ksis'],
                ':schedule': config_data.get('schedule', 'daily')
            }
        )
        
        return cors_response(200, {'message': 'KSI configuration updated'})
    except Exception as e:
        return cors_response(500, {'error': str(e)})

def get_available_ksis():
    """Get available KSIs from validation rules table"""
    table = dynamodb.Table(VALIDATION_RULES_TABLE)
    
    try:
        # Get all active rules
        response = table.query(
            IndexName='status-index',
            KeyConditionExpression='#status = :status',
            ExpressionAttributeNames={'#status': 'status'},
            ExpressionAttributeValues={':status': 'active'}
        )
        
        ksis = []
        for rule in response.get('Items', []):
            ksis.append({
                'ksi_id': rule['ksi_id'],
                'title': rule['title'],
                'category': rule['category'],
                'description': rule['description'],
                'version': rule['version'],
                'command_count': len(rule.get('validation_steps', []))
            })
        
        return cors_response(200, {'available_ksis': ksis})
        
    except Exception as e:
        logger.error(f"Error getting available KSIs: {str(e)}")
        return cors_response(500, {'error': str(e)})

def trigger_tenant_validation(tenant_id):
    """Trigger validation for tenant"""
    # Basic implementation - you can enhance this
    return cors_response(200, {
        'message': 'Validation triggered',
        'tenant_id': tenant_id,
        'status': 'pending'
    })

def tenant_exists(tenant_id: str) -> bool:
    """Check if tenant exists"""
    try:
        table = dynamodb.Table(TENANTS_TABLE)
        response = table.get_item(Key={'tenant_id': tenant_id})
        return 'Item' in response
    except:
        return False
